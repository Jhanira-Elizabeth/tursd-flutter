# --- 1. Importaciones ---
import os
os.system("pip install -r requirements.txt")
import psycopg2
import unicodedata
import traceback
from flask import Flask, request, jsonify
from dotenv import load_dotenv

# --- 2. Cargar Variables de Entorno desde .env ---
load_dotenv()

# --- 3. Configuración de Variables Globales para Conexiones ---
conn = None

# --- 4. Función para Inicializar Conexión a la base de datos ---
def initialize_connections():
    global conn
    # Conexión a PostgreSQL
    try:
        db_host = os.getenv("DB_HOST")
        db_port = os.getenv("DB_PORT")
        db_name = os.getenv("DB_NAME")
        db_user = os.getenv("DB_USER")
        db_pass = os.getenv("DB_PASS")

        if all([db_host, db_port, db_name, db_user, db_pass]):
            DATABASE_URL = f"postgresql://{db_user}:{db_pass}@{db_host}:{db_port}/{db_name}?sslmode=require"
            print(f"DEBUG: Construyendo DATABASE_URL: {DATABASE_URL}")
            conn = psycopg2.connect(DATABASE_URL)
            conn.autocommit = True
            print("✅ Conexión a PostgreSQL establecida correctamente.")
        else:
            print("⚠️ Faltan variables de entorno para PostgreSQL (DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASS). Conexión no establecida.")
            conn = None
    except Exception as e:
        print(f"❌ ERROR: Fallo al conectar a PostgreSQL: {e}")
        traceback.print_exc()
        conn = None

# --- Llama a la función de inicialización al inicio ---
initialize_connections()

# Inicializar Flask
app = Flask(__name__)

# --- Utilidad para quitar tildes ---
def quitar_tildes(texto):
    if not isinstance(texto, str):
        return texto
    return ''.join(
        c for c in unicodedata.normalize('NFD', texto)
        if unicodedata.category(c) != 'Mn'
    )

# --- Funciones principales ---

def obtener_lugares_cercanos(lat, lon, radio_km=30):
    print("[DEBUG] obtener_lugares_cercanos llamada con:")
    print(f"  lat: {lat}, lon: {lon}, radio_km: {radio_km}")
    if conn is None:
        print("[DEBUG] Conexión a DB no establecida (conn is None)")
        return "No se pudo cargar la información de lugares cercanos (conexión DB no establecida)."
    contexto_cercanos = []
    MAX_LUGARES = 10
    try:
        with conn.cursor() as cur:
            # Locales turísticos
            query_locales = '''
                SELECT
                    lt.nombre AS nombre_local, lt.descripcion AS descripcion_local,
                    p.nombre AS nombre_parroquia,
                    STRING_AGG(DISTINCT sl.servicio, ', ') AS servicios_ofrecidos,
                    6371 * acos(
                        cos(radians(%s)) * cos(radians(lt.latitud)) * cos(radians(lt.longitud) - radians(%s)) +
                        sin(radians(%s)) * sin(radians(lt.latitud))
                    ) AS distance_km,
                    lt.latitud, lt.longitud
                FROM locales_turisticos lt
                LEFT JOIN parroquias p ON lt.id_parroquia = p.id
                LEFT JOIN servicios_locales sl ON lt.id = sl.id_local
                WHERE lt.latitud IS NOT NULL AND lt.longitud IS NOT NULL AND lt.estado = 'true'
                GROUP BY lt.id, lt.nombre, lt.descripcion, p.nombre, lt.latitud, lt.longitud
                HAVING 6371 * acos(
                    cos(radians(%s)) * cos(radians(lt.latitud)) * cos(radians(lt.longitud) - radians(%s)) +
                    sin(radians(%s)) * sin(radians(lt.latitud))
                ) < %s
                ORDER BY distance_km
                LIMIT 10;
            '''
            params_locales = (lat, lon, lat, lat, lon, lat, radio_km)
            cur.execute(query_locales, params_locales)
            filas_locales = cur.fetchall()
            for fila in filas_locales:
                servicios_str = fila[3] if fila[3] else 'No especificados'
                contexto_cercanos.append(
                    f"- **Local Cercano:** {fila[0]} (Lat: {fila[5]}, Lon: {fila[6]})\n"
                    f"  **Descripción:** {fila[1]}\n"
                    f"  **Parroquia:** {fila[2]}\n"
                    f"  **Servicios:** {servicios_str}\n"
                    f"  **Distancia:** {fila[4]:.2f} km\n"
                )
            # Puntos turísticos
            query_puntos = '''
                SELECT
                    pt.nombre AS nombre_punto, pt.descripcion AS descripcion_punto,
                    p.nombre AS nombre_parroquia,
                    STRING_AGG(DISTINCT apt.actividad, ', ') AS actividades_disponibles,
                    6371 * acos(
                        cos(radians(%s)) * cos(radians(pt.latitud)) * cos(radians(pt.longitud) - radians(%s)) +
                        sin(radians(%s)) * sin(radians(pt.latitud))
                    ) AS distance_km,
                    pt.latitud, pt.longitud
                FROM puntos_turisticos pt
                LEFT JOIN parroquias p ON pt.id_parroquia = p.id
                LEFT JOIN actividad_punto_turistico apt ON pt.id = apt.id_punto_turistico
                WHERE pt.latitud IS NOT NULL AND pt.longitud IS NOT NULL AND pt.estado = 'true'
                GROUP BY pt.id, pt.nombre, pt.descripcion, p.nombre, pt.latitud, pt.longitud
                HAVING 6371 * acos(
                    cos(radians(%s)) * cos(radians(pt.latitud)) * cos(radians(pt.longitud) - radians(%s)) +
                    sin(radians(%s)) * sin(radians(pt.latitud))
                ) < %s
                ORDER BY distance_km
                LIMIT 10;
            '''
            params_puntos = (lat, lon, lat, lat, lon, lat, radio_km)
            cur.execute(query_puntos, params_puntos)
            filas_puntos = cur.fetchall()
            for fila in filas_puntos:
                actividades_str = fila[3] if fila[3] else 'No especificadas'
                contexto_cercanos.append(
                    f"- **Punto Turístico Cercano:** {fila[0]} (Lat: {fila[5]}, Lon: {fila[6]})\n"
                    f"  **Descripción:** {fila[1]}\n"
                    f"  **Parroquia:** {fila[2]}\n"
                    f"  **Actividades:** {actividades_str}\n"
                    f"  **Distancia:** {fila[4]:.2f} km\n"
                )
    except Exception as e:
        print(f"❌ ERROR: Fallo al obtener lugares cercanos: {e}")
        traceback.print_exc()
        return "No se pudo cargar la información de lugares cercanos."
    return "\n".join(contexto_cercanos) if contexto_cercanos else "No se encontraron lugares o puntos turísticos cercanos con las coordenadas proporcionadas."

# --- Rutas de la API ---

@app.route("/")
def home():
    return "¡Bienvenido al asistente turístico de Ecuador! El servicio de chatbot está disponible en /chat."

@app.route("/chat", methods=["POST"])
def chat():
    MENU_OPCIONES = [
        "Étnia Tsáchila",
        "Alojamientos",
        "Parques",
        "Rios",
        "Atracciones Estables",
        "Alimentos",
        "Balnearios"
    ]
    if conn is None:
        return jsonify({"response": "Lo siento, el servicio de base de datos no está disponible en este momento."}), 503
    try:
        data = request.json
        chat_id = data.get("chat_id")
        seleccion = data.get("seleccion")
        if not seleccion:
            saludo = "¡Hola viajero! ¿Qué te gustaría explorar en Santo Domingo de los Tsáchilas? Por favor elige una opción:"
            opciones = "\n".join([f"- {op}" for op in MENU_OPCIONES])
            return jsonify({
                "response": f"{saludo}\n\n{opciones}",
                "menu": MENU_OPCIONES
            })
        etiqueta = seleccion.strip()
        etiqueta_normalizada = quitar_tildes(etiqueta).lower()
        with conn.cursor() as cur:
            # Buscar en locales_turisticos
            query_locales = '''
                SELECT lt.nombre, lt.descripcion, p.nombre AS parroquia, et.nombre AS etiqueta
                FROM locales_turisticos lt
                LEFT JOIN local_etiqueta le ON lt.id = le.id_local
                LEFT JOIN etiquetas_turisticas et ON le.id_etiqueta = et.id
                LEFT JOIN parroquias p ON lt.id_parroquia = p.id
                WHERE lt.estado = 'activo'
                GROUP BY lt.id, lt.nombre, lt.descripcion, p.nombre, et.nombre
                LIMIT 100;
            '''
            cur.execute(query_locales)
            resultados_locales = [row for row in cur.fetchall() if quitar_tildes(str(row[3] or '')).lower() == etiqueta_normalizada]
            # Buscar en puntos_turisticos
            query_puntos = '''
                SELECT pt.nombre, pt.descripcion, p.nombre AS parroquia, et.nombre AS etiqueta
                FROM puntos_turisticos pt
                LEFT JOIN puntos_turisticos_etiqueta pte ON pt.id = pte.id_punto_turistico
                LEFT JOIN etiquetas_turisticas et ON pte.id_etiqueta = et.id
                LEFT JOIN parroquias p ON pt.id_parroquia = p.id
                WHERE pt.estado = 'activo'
                GROUP BY pt.id, pt.nombre, pt.descripcion, p.nombre, et.nombre
                LIMIT 100;
            '''
            cur.execute(query_puntos)
            resultados_puntos = [row for row in cur.fetchall() if quitar_tildes(str(row[3] or '')).lower() == etiqueta_normalizada]
            # Búsqueda flexible si no hay resultados exactos
            if not resultados_locales and not resultados_puntos:
                palabras = etiqueta.split()
                palabras_normalizadas = [quitar_tildes(p).lower() for p in palabras]
                # Locales flex
                query_locales_flex = '''
                    SELECT lt.nombre, lt.descripcion, p.nombre AS parroquia
                    FROM locales_turisticos lt
                    LEFT JOIN parroquias p ON lt.id_parroquia = p.id
                    WHERE lt.estado = 'activo'
                    GROUP BY lt.id, lt.nombre, lt.descripcion, p.nombre
                    LIMIT 100;
                '''
                cur.execute(query_locales_flex)
                resultados_locales = []
                for row in cur.fetchall():
                    nombre_norm = quitar_tildes(str(row[0] or '')).lower()
                    desc_norm = quitar_tildes(str(row[1] or '')).lower()
                    if any(p in nombre_norm or p in desc_norm for p in palabras_normalizadas):
                        resultados_locales.append(row)
                # Puntos flex
                query_puntos_flex = '''
                    SELECT pt.nombre, pt.descripcion, p.nombre AS parroquia
                    FROM puntos_turisticos pt
                    LEFT JOIN parroquias p ON pt.id_parroquia = p.id
                    WHERE pt.estado = 'activo'
                    GROUP BY pt.id, pt.nombre, pt.descripcion, p.nombre
                    LIMIT 100;
                '''
                cur.execute(query_puntos_flex)
                resultados_puntos = []
                for row in cur.fetchall():
                    nombre_norm = quitar_tildes(str(row[0] or '')).lower()
                    desc_norm = quitar_tildes(str(row[1] or '')).lower()
                    if any(p in nombre_norm or p in desc_norm for p in palabras_normalizadas):
                        resultados_puntos.append(row)
        respuesta = f"Resultados para la búsqueda **{etiqueta}** en Santo Domingo de los Tsáchilas:\n\n"
        if not resultados_locales and not resultados_puntos:
            respuesta += "No se encontraron lugares o puntos turísticos para esta búsqueda."
        else:
            for row in resultados_locales:
                nombre, descripcion, parroquia = row[:3]
                respuesta += f"- **{nombre}**\n  {descripcion}\n  _Ubicación: Parroquia {parroquia}_\n\n"
            for row in resultados_puntos:
                nombre, descripcion, parroquia = row[:3]
                respuesta += f"- **{nombre}**\n  {descripcion}\n  _Ubicación: Parroquia {parroquia}_\n\n"
        return jsonify({"response": respuesta.strip()})
    except Exception as e:
        print(f"❌ ERROR en la ruta /chat (menú guiado): {e}")
        traceback.print_exc()
        return jsonify({"response": "Lo siento, ocurrió un error interno al procesar tu solicitud. Por favor intenta de nuevo más tarde."}), 500

# --- Ejecutar la aplicación Flask ---
if __name__ == "__main__":
    PORT = int(os.getenv('PORT', 8000))
    print(f"Iniciando Flask en el puerto {PORT}...")
    app.run(host="0.0.0.0", port=PORT, debug=True)
